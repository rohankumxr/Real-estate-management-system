﻿namespace ACCOUNTMANAGEMENT
{
    partial class SALESINVOICEcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SALESINVOICEcs));
            this.label17 = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.btnAd = new System.Windows.Forms.Button();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.lblcustid = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtitemno = new System.Windows.Forms.TextBox();
            this.cmbitemname = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtunit = new System.Windows.Forms.TextBox();
            this.txtmrp = new System.Windows.Forms.TextBox();
            this.txtdiscper = new System.Windows.Forms.TextBox();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.txttaxname = new System.Windows.Forms.TextBox();
            this.txttax = new System.Windows.Forms.TextBox();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.dgwSales = new System.Windows.Forms.DataGridView();
            this.Slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SerialNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModelNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txttotdiscount = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPaymentDue = new System.Windows.Forms.TextBox();
            this.txtTotalPayment = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.payment = new System.Windows.Forms.Label();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtTotqty = new System.Windows.Forms.TextBox();
            this.txttotaltax = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblpath = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpCreditDate = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSerialNo = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtModelNo = new System.Windows.Forms.TextBox();
            this.txtBasicAmount = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.lblSlNo = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblunitid = new System.Windows.Forms.Label();
            this.lblTaxid = new System.Windows.Forms.Label();
            this.txtNetAmount = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtlrno = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txttransport = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSales)).BeginInit();
            this.GroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(17, 18);
            this.label17.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 17);
            this.label17.TabIndex = 251;
            this.label17.Text = "Date";
            // 
            // dtpDate
            // 
            this.dtpDate.CustomFormat = "dd/MM/yyyy";
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(63, 18);
            this.dtpDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(115, 24);
            this.dtpDate.TabIndex = 250;
            // 
            // btnAd
            // 
            this.btnAd.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAd.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAd.ForeColor = System.Drawing.Color.Green;
            this.btnAd.Location = new System.Drawing.Point(933, 15);
            this.btnAd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAd.Name = "btnAd";
            this.btnAd.Size = new System.Drawing.Size(31, 35);
            this.btnAd.TabIndex = 246;
            this.btnAd.Text = "+";
            this.btnAd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAd.UseVisualStyleBackColor = true;
            this.btnAd.Click += new System.EventHandler(this.btnAd_Click);
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.Location = new System.Drawing.Point(563, 19);
            this.cmbCustomer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(362, 25);
            this.cmbCustomer.TabIndex = 245;
            this.cmbCustomer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbCustomer_KeyDown);
            // 
            // lblcustid
            // 
            this.lblcustid.AutoSize = true;
            this.lblcustid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblcustid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcustid.Location = new System.Drawing.Point(422, 23);
            this.lblcustid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblcustid.Name = "lblcustid";
            this.lblcustid.Size = new System.Drawing.Size(14, 17);
            this.lblcustid.TabIndex = 248;
            this.lblcustid.Text = "0";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblCompanyName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCompanyName.Location = new System.Drawing.Point(441, 23);
            this.lblCompanyName.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(98, 17);
            this.lblCompanyName.TabIndex = 247;
            this.lblCompanyName.Text = "Customer Name";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Location = new System.Drawing.Point(260, 19);
            this.txtinvoiceno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(112, 24);
            this.txtinvoiceno.TabIndex = 254;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(188, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 255;
            this.label2.Text = "Invoice No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(330, 49);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 17);
            this.label3.TabIndex = 257;
            this.label3.Text = "Item Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(74, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 17);
            this.label4.TabIndex = 259;
            this.label4.Text = "Qty";
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(53, 146);
            this.txtqty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(67, 24);
            this.txtqty.TabIndex = 258;
            this.txtqty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtqty_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(258, 118);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 17);
            this.label5.TabIndex = 261;
            this.label5.Text = "Price";
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(221, 146);
            this.txtprice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(114, 24);
            this.txtprice.TabIndex = 260;
            this.txtprice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtprice_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(110, 48);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 263;
            this.label6.Text = "Item No";
            // 
            // txtitemno
            // 
            this.txtitemno.Location = new System.Drawing.Point(89, 75);
            this.txtitemno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtitemno.Name = "txtitemno";
            this.txtitemno.Size = new System.Drawing.Size(100, 24);
            this.txtitemno.TabIndex = 262;
            this.txtitemno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtitemno_KeyDown);
            // 
            // cmbitemname
            // 
            this.cmbitemname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbitemname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbitemname.FormattingEnabled = true;
            this.cmbitemname.Location = new System.Drawing.Point(206, 75);
            this.cmbitemname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbitemname.Name = "cmbitemname";
            this.cmbitemname.Size = new System.Drawing.Size(370, 25);
            this.cmbitemname.TabIndex = 264;
            this.cmbitemname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbitemname_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(848, 114);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 266;
            this.label7.Text = "Discount%";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(381, 118);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 17);
            this.label8.TabIndex = 268;
            this.label8.Text = "Mrp";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(937, 112);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 17);
            this.label9.TabIndex = 269;
            this.label9.Text = "Discount";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(575, 114);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 17);
            this.label10.TabIndex = 270;
            this.label10.Text = "Tax Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(667, 114);
            this.label11.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 17);
            this.label11.TabIndex = 271;
            this.label11.Text = "Tax Amount";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(150, 116);
            this.label12.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 17);
            this.label12.TabIndex = 272;
            this.label12.Text = "unit";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(1043, 112);
            this.label13.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 17);
            this.label13.TabIndex = 273;
            this.label13.Text = "Amount";
            // 
            // txtunit
            // 
            this.txtunit.Location = new System.Drawing.Point(130, 146);
            this.txtunit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtunit.Name = "txtunit";
            this.txtunit.ReadOnly = true;
            this.txtunit.Size = new System.Drawing.Size(77, 24);
            this.txtunit.TabIndex = 274;
            // 
            // txtmrp
            // 
            this.txtmrp.Location = new System.Drawing.Point(344, 146);
            this.txtmrp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtmrp.Name = "txtmrp";
            this.txtmrp.ReadOnly = true;
            this.txtmrp.Size = new System.Drawing.Size(114, 24);
            this.txtmrp.TabIndex = 275;
            // 
            // txtdiscper
            // 
            this.txtdiscper.Location = new System.Drawing.Point(844, 145);
            this.txtdiscper.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtdiscper.Name = "txtdiscper";
            this.txtdiscper.Size = new System.Drawing.Size(77, 24);
            this.txtdiscper.TabIndex = 276;
            this.txtdiscper.Text = "0";
            this.txtdiscper.TextChanged += new System.EventHandler(this.txtdiscper_TextChanged);
            this.txtdiscper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtdiscper_KeyDown);
            // 
            // txtdiscount
            // 
            this.txtdiscount.Location = new System.Drawing.Point(930, 144);
            this.txtdiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(77, 24);
            this.txtdiscount.TabIndex = 277;
            this.txtdiscount.Text = "0";
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged);
            this.txtdiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtdiscount_KeyDown);
            // 
            // txttaxname
            // 
            this.txttaxname.Location = new System.Drawing.Point(562, 146);
            this.txttaxname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttaxname.Name = "txttaxname";
            this.txttaxname.ReadOnly = true;
            this.txttaxname.Size = new System.Drawing.Size(91, 24);
            this.txttaxname.TabIndex = 278;
            // 
            // txttax
            // 
            this.txttax.Location = new System.Drawing.Point(660, 146);
            this.txttax.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttax.Name = "txttax";
            this.txttax.ReadOnly = true;
            this.txttax.Size = new System.Drawing.Size(84, 24);
            this.txttax.TabIndex = 279;
            // 
            // txtamount
            // 
            this.txtamount.Location = new System.Drawing.Point(1019, 143);
            this.txtamount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtamount.Name = "txtamount";
            this.txtamount.ReadOnly = true;
            this.txtamount.Size = new System.Drawing.Size(119, 24);
            this.txtamount.TabIndex = 280;
            // 
            // dgwSales
            // 
            this.dgwSales.AllowUserToAddRows = false;
            this.dgwSales.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FloralWhite;
            this.dgwSales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgwSales.BackgroundColor = System.Drawing.Color.White;
            this.dgwSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwSales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgwSales.ColumnHeadersHeight = 24;
            this.dgwSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Slno,
            this.GroupId,
            this.dataGridViewTextBoxColumn1,
            this.SerialNo,
            this.ModelNo,
            this.Qty,
            this.Rate,
            this.amount,
            this.Tax,
            this.NetAmount,
            this.Discount,
            this.Amount1});
            this.dgwSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgwSales.EnableHeadersVisualStyles = false;
            this.dgwSales.GridColor = System.Drawing.Color.White;
            this.dgwSales.Location = new System.Drawing.Point(14, 184);
            this.dgwSales.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgwSales.MultiSelect = false;
            this.dgwSales.Name = "dgwSales";
            this.dgwSales.ReadOnly = true;
            this.dgwSales.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwSales.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgwSales.RowHeadersWidth = 25;
            this.dgwSales.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.MediumTurquoise;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.dgwSales.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgwSales.RowTemplate.Height = 18;
            this.dgwSales.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwSales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgwSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwSales.Size = new System.Drawing.Size(1159, 303);
            this.dgwSales.TabIndex = 281;
            this.dgwSales.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwCompany_CellContentClick);
            // 
            // Slno
            // 
            this.Slno.HeaderText = "Sl.No.";
            this.Slno.Name = "Slno";
            this.Slno.ReadOnly = true;
            this.Slno.Width = 40;
            // 
            // GroupId
            // 
            this.GroupId.HeaderText = "Id";
            this.GroupId.Name = "GroupId";
            this.GroupId.ReadOnly = true;
            this.GroupId.Width = 70;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Item Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // SerialNo
            // 
            this.SerialNo.HeaderText = "SerialNo";
            this.SerialNo.Name = "SerialNo";
            this.SerialNo.ReadOnly = true;
            // 
            // ModelNo
            // 
            this.ModelNo.HeaderText = "ModelNo";
            this.ModelNo.Name = "ModelNo";
            this.ModelNo.ReadOnly = true;
            // 
            // Qty
            // 
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            this.Qty.ReadOnly = true;
            this.Qty.Width = 50;
            // 
            // Rate
            // 
            this.Rate.HeaderText = "Rate";
            this.Rate.Name = "Rate";
            this.Rate.ReadOnly = true;
            // 
            // amount
            // 
            this.amount.HeaderText = "Basic Amount";
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            // 
            // Tax
            // 
            this.Tax.HeaderText = "Tax";
            this.Tax.Name = "Tax";
            this.Tax.ReadOnly = true;
            // 
            // NetAmount
            // 
            this.NetAmount.HeaderText = "NetAmount";
            this.NetAmount.Name = "NetAmount";
            this.NetAmount.ReadOnly = true;
            // 
            // Discount
            // 
            this.Discount.HeaderText = "Discount";
            this.Discount.Name = "Discount";
            this.Discount.ReadOnly = true;
            // 
            // Amount1
            // 
            this.Amount1.HeaderText = "Amount";
            this.Amount1.Name = "Amount1";
            this.Amount1.ReadOnly = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(583, 498);
            this.label14.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 17);
            this.label14.TabIndex = 283;
            this.label14.Text = "Total Qty";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(583, 531);
            this.label15.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 17);
            this.label15.TabIndex = 285;
            this.label15.Text = "Total Discount";
            // 
            // txttotdiscount
            // 
            this.txttotdiscount.Location = new System.Drawing.Point(699, 528);
            this.txttotdiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttotdiscount.Name = "txttotdiscount";
            this.txttotdiscount.Size = new System.Drawing.Size(131, 24);
            this.txttotdiscount.TabIndex = 284;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(583, 567);
            this.label18.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(107, 17);
            this.label18.TabIndex = 288;
            this.label18.Text = "Total Tax Amount";
            // 
            // txtPaymentDue
            // 
            this.txtPaymentDue.Location = new System.Drawing.Point(945, 564);
            this.txtPaymentDue.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPaymentDue.Name = "txtPaymentDue";
            this.txtPaymentDue.ReadOnly = true;
            this.txtPaymentDue.Size = new System.Drawing.Size(114, 24);
            this.txtPaymentDue.TabIndex = 295;
            this.txtPaymentDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalPayment
            // 
            this.txtTotalPayment.Location = new System.Drawing.Point(945, 529);
            this.txtTotalPayment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotalPayment.Name = "txtTotalPayment";
            this.txtTotalPayment.Size = new System.Drawing.Size(114, 24);
            this.txtTotalPayment.TabIndex = 290;
            this.txtTotalPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotalPayment.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTotalPayment_KeyUp);
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(836, 566);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(83, 17);
            this.Label19.TabIndex = 294;
            this.Label19.Text = "Payment Due";
            // 
            // payment
            // 
            this.payment.AutoSize = true;
            this.payment.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payment.Location = new System.Drawing.Point(836, 531);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(89, 17);
            this.payment.TabIndex = 293;
            this.payment.Text = "Total Payment";
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.Location = new System.Drawing.Point(945, 494);
            this.txtGrandTotal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.ReadOnly = true;
            this.txtGrandTotal.Size = new System.Drawing.Size(114, 24);
            this.txtGrandTotal.TabIndex = 291;
            this.txtGrandTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(837, 500);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 17);
            this.label20.TabIndex = 292;
            this.label20.Text = "Grand Total";
            // 
            // txtTotqty
            // 
            this.txtTotqty.Location = new System.Drawing.Point(699, 494);
            this.txtTotqty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotqty.Name = "txtTotqty";
            this.txtTotqty.ReadOnly = true;
            this.txtTotqty.Size = new System.Drawing.Size(131, 24);
            this.txtTotqty.TabIndex = 296;
            this.txtTotqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttotaltax
            // 
            this.txttotaltax.Location = new System.Drawing.Point(699, 563);
            this.txttotaltax.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttotaltax.Name = "txttotaltax";
            this.txttotaltax.ReadOnly = true;
            this.txttotaltax.Size = new System.Drawing.Size(131, 24);
            this.txttotaltax.TabIndex = 297;
            this.txttotaltax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.btnDelete);
            this.GroupBox3.Controls.Add(this.btnUpdate);
            this.GroupBox3.Controls.Add(this.btnNew);
            this.GroupBox3.Controls.Add(this.btnSave);
            this.GroupBox3.Controls.Add(this.btnClose);
            this.GroupBox3.Location = new System.Drawing.Point(12, 526);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(441, 62);
            this.GroupBox3.TabIndex = 298;
            this.GroupBox3.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(263, 16);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(82, 37);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(179, 16);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(82, 37);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.Location = new System.Drawing.Point(8, 14);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(82, 37);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "&New";
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(94, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(82, 37);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(350, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(82, 37);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblpath
            // 
            this.lblpath.AutoSize = true;
            this.lblpath.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblpath.Location = new System.Drawing.Point(1295, 14);
            this.lblpath.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblpath.Name = "lblpath";
            this.lblpath.Size = new System.Drawing.Size(0, 17);
            this.lblpath.TabIndex = 299;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(480, 531);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 17);
            this.label1.TabIndex = 300;
            this.label1.Text = "Credit Date";
            // 
            // dtpCreditDate
            // 
            this.dtpCreditDate.CustomFormat = "dd/MM/yyyy";
            this.dtpCreditDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCreditDate.Location = new System.Drawing.Point(459, 559);
            this.dtpCreditDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpCreditDate.Name = "dtpCreditDate";
            this.dtpCreditDate.Size = new System.Drawing.Size(115, 24);
            this.dtpCreditDate.TabIndex = 301;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(693, 48);
            this.label16.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 17);
            this.label16.TabIndex = 303;
            this.label16.Text = "Serial No";
            // 
            // txtSerialNo
            // 
            this.txtSerialNo.Location = new System.Drawing.Point(595, 76);
            this.txtSerialNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSerialNo.Name = "txtSerialNo";
            this.txtSerialNo.Size = new System.Drawing.Size(258, 24);
            this.txtSerialNo.TabIndex = 302;
            this.txtSerialNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSerialNo_KeyDown);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(961, 49);
            this.label21.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 17);
            this.label21.TabIndex = 305;
            this.label21.Text = "Model No";
            // 
            // txtModelNo
            // 
            this.txtModelNo.Location = new System.Drawing.Point(863, 75);
            this.txtModelNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtModelNo.Name = "txtModelNo";
            this.txtModelNo.Size = new System.Drawing.Size(275, 24);
            this.txtModelNo.TabIndex = 304;
            this.txtModelNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtModelNo_KeyDown);
            // 
            // txtBasicAmount
            // 
            this.txtBasicAmount.Location = new System.Drawing.Point(468, 146);
            this.txtBasicAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBasicAmount.Name = "txtBasicAmount";
            this.txtBasicAmount.ReadOnly = true;
            this.txtBasicAmount.Size = new System.Drawing.Size(89, 24);
            this.txtBasicAmount.TabIndex = 307;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(471, 117);
            this.label22.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 17);
            this.label22.TabIndex = 306;
            this.label22.Text = "Basic Amount";
            // 
            // lblSlNo
            // 
            this.lblSlNo.AutoSize = true;
            this.lblSlNo.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblSlNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSlNo.Location = new System.Drawing.Point(51, 77);
            this.lblSlNo.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblSlNo.Name = "lblSlNo";
            this.lblSlNo.Size = new System.Drawing.Size(14, 17);
            this.lblSlNo.TabIndex = 308;
            this.lblSlNo.Text = "1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(37, 49);
            this.label23.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 17);
            this.label23.TabIndex = 309;
            this.label23.Text = "Sl. No.";
            // 
            // lblunitid
            // 
            this.lblunitid.AutoSize = true;
            this.lblunitid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblunitid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblunitid.Location = new System.Drawing.Point(180, 118);
            this.lblunitid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblunitid.Name = "lblunitid";
            this.lblunitid.Size = new System.Drawing.Size(14, 17);
            this.lblunitid.TabIndex = 310;
            this.lblunitid.Text = "1";
            // 
            // lblTaxid
            // 
            this.lblTaxid.AutoSize = true;
            this.lblTaxid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblTaxid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTaxid.Location = new System.Drawing.Point(637, 114);
            this.lblTaxid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblTaxid.Name = "lblTaxid";
            this.lblTaxid.Size = new System.Drawing.Size(14, 17);
            this.lblTaxid.TabIndex = 311;
            this.lblTaxid.Text = "1";
            // 
            // txtNetAmount
            // 
            this.txtNetAmount.Location = new System.Drawing.Point(748, 145);
            this.txtNetAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNetAmount.Name = "txtNetAmount";
            this.txtNetAmount.ReadOnly = true;
            this.txtNetAmount.Size = new System.Drawing.Size(89, 24);
            this.txtNetAmount.TabIndex = 313;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(751, 116);
            this.label24.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 17);
            this.label24.TabIndex = 312;
            this.label24.Text = "Net Amount";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(9, 498);
            this.label25.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 17);
            this.label25.TabIndex = 315;
            this.label25.Text = "L.R. NO.";
            // 
            // txtlrno
            // 
            this.txtlrno.Location = new System.Drawing.Point(66, 497);
            this.txtlrno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtlrno.Name = "txtlrno";
            this.txtlrno.Size = new System.Drawing.Size(131, 24);
            this.txtlrno.TabIndex = 314;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label26.Location = new System.Drawing.Point(197, 501);
            this.label26.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(109, 17);
            this.label26.TabIndex = 317;
            this.label26.Text = "TRANSPORT BY.";
            // 
            // txttransport
            // 
            this.txttransport.Location = new System.Drawing.Point(311, 498);
            this.txttransport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttransport.Name = "txttransport";
            this.txttransport.Size = new System.Drawing.Size(263, 24);
            this.txttransport.TabIndex = 316;
            // 
            // SALESINVOICEcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1185, 597);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txttransport);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtlrno);
            this.Controls.Add(this.txtNetAmount);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.lblTaxid);
            this.Controls.Add(this.lblunitid);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.lblSlNo);
            this.Controls.Add(this.txtBasicAmount);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtModelNo);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtSerialNo);
            this.Controls.Add(this.dtpCreditDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblpath);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.txttotaltax);
            this.Controls.Add(this.txtTotqty);
            this.Controls.Add(this.txtPaymentDue);
            this.Controls.Add(this.txtTotalPayment);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.payment);
            this.Controls.Add(this.txtGrandTotal);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txttotdiscount);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dgwSales);
            this.Controls.Add(this.txtamount);
            this.Controls.Add(this.txttax);
            this.Controls.Add(this.txttaxname);
            this.Controls.Add(this.txtdiscount);
            this.Controls.Add(this.txtdiscper);
            this.Controls.Add(this.txtmrp);
            this.Controls.Add(this.txtunit);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbitemname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtitemno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtinvoiceno);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.btnAd);
            this.Controls.Add(this.cmbCustomer);
            this.Controls.Add(this.lblcustid);
            this.Controls.Add(this.lblCompanyName);
            this.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "SALESINVOICEcs";
            this.Text = "SALESINVOICEcs";
            ((System.ComponentModel.ISupportInitialize)(this.dgwSales)).EndInit();
            this.GroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        internal System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Button btnAd;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.Label lblcustid;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtitemno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtunit;
        private System.Windows.Forms.TextBox txtmrp;
        private System.Windows.Forms.TextBox txtdiscper;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.TextBox txttaxname;
        private System.Windows.Forms.TextBox txttax;
        private System.Windows.Forms.TextBox txtamount;
        internal System.Windows.Forms.DataGridView dgwSales;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txttotdiscount;
        private System.Windows.Forms.Label label18;
        internal System.Windows.Forms.TextBox txtPaymentDue;
        internal System.Windows.Forms.TextBox txtTotalPayment;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label payment;
        internal System.Windows.Forms.TextBox txtGrandTotal;
        internal System.Windows.Forms.Label label20;
        internal System.Windows.Forms.TextBox txtTotqty;
        internal System.Windows.Forms.TextBox txttotaltax;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnUpdate;
        internal System.Windows.Forms.Button btnNew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnClose;
        public System.Windows.Forms.Label lblpath;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.DateTimePicker dtpCreditDate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSerialNo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtModelNo;
        private System.Windows.Forms.TextBox txtBasicAmount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblSlNo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblunitid;
        private System.Windows.Forms.Label lblTaxid;
        private System.Windows.Forms.TextBox txtNetAmount;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtlrno;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txttransport;
        private System.Windows.Forms.DataGridViewTextBoxColumn Slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SerialNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModelNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tax;
        private System.Windows.Forms.DataGridViewTextBoxColumn NetAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount1;
        public System.Windows.Forms.ComboBox cmbitemname;
    }
}