﻿namespace ACCOUNTMANAGEMENT
{
    partial class OPTICALSALE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label23 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbal = new System.Windows.Forms.TextBox();
            this.txtadv = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtpurticulars = new System.Windows.Forms.TextBox();
            this.lblopticalid = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblno = new System.Windows.Forms.Label();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lbllefteye = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblglassidleft = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtldva = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtlnaxis = new System.Windows.Forms.TextBox();
            this.txtldaxis = new System.Windows.Forms.TextBox();
            this.txtlncyl = new System.Windows.Forms.TextBox();
            this.txtldcyl = new System.Windows.Forms.TextBox();
            this.txtlnsph = new System.Windows.Forms.TextBox();
            this.txtldsph = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblrighteye = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblglassidright = new System.Windows.Forms.Label();
            this.txtrdva = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtrnaxis = new System.Windows.Forms.TextBox();
            this.txtrdaxis = new System.Windows.Forms.TextBox();
            this.txtrncyl = new System.Windows.Forms.TextBox();
            this.txtrdcyl = new System.Windows.Forms.TextBox();
            this.txtrnsph = new System.Windows.Forms.TextBox();
            this.txtrdsph = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.lbltempid = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtmo = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtcustomer = new System.Windows.Forms.TextBox();
            this.dtpinvoice = new System.Windows.Forms.DateTimePicker();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.txtInvoiceNo = new System.Windows.Forms.TextBox();
            this.lblInvoiceNo = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(647, 302);
            this.label23.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 13);
            this.label23.TabIndex = 783;
            this.label23.Text = "Balance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(647, 263);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 782;
            this.label6.Text = "Advance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(647, 218);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 781;
            this.label4.Text = "Total";
            // 
            // txtbal
            // 
            this.txtbal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbal.Location = new System.Drawing.Point(718, 299);
            this.txtbal.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtbal.MaxLength = 15;
            this.txtbal.Name = "txtbal";
            this.txtbal.Size = new System.Drawing.Size(72, 20);
            this.txtbal.TabIndex = 6;
            // 
            // txtadv
            // 
            this.txtadv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadv.Location = new System.Drawing.Point(718, 260);
            this.txtadv.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtadv.MaxLength = 15;
            this.txtadv.Name = "txtadv";
            this.txtadv.Size = new System.Drawing.Size(72, 20);
            this.txtadv.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtbal);
            this.panel2.Controls.Add(this.txtadv);
            this.panel2.Controls.Add(this.txttotal);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.lbllefteye);
            this.panel2.Controls.Add(this.btnReset);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.lblrighteye);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(23, 122);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1272, 367);
            this.panel2.TabIndex = 815;
            this.panel2.Tag = "";
            // 
            // txttotal
            // 
            this.txttotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotal.Location = new System.Drawing.Point(718, 215);
            this.txttotal.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txttotal.MaxLength = 15;
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(72, 20);
            this.txttotal.TabIndex = 4;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            this.btnClose.Location = new System.Drawing.Point(1116, 285);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(85, 27);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txtpurticulars);
            this.panel1.Controls.Add(this.lblopticalid);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblno);
            this.panel1.Controls.Add(this.txtRate);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtAmount);
            this.panel1.Controls.Add(this.txtQty);
            this.panel1.Location = new System.Drawing.Point(15, 194);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(588, 164);
            this.panel1.TabIndex = 3;
            this.panel1.Tag = "";
            // 
            // txtpurticulars
            // 
            this.txtpurticulars.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpurticulars.Location = new System.Drawing.Point(93, 43);
            this.txtpurticulars.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtpurticulars.MaxLength = 15;
            this.txtpurticulars.Name = "txtpurticulars";
            this.txtpurticulars.Size = new System.Drawing.Size(434, 22);
            this.txtpurticulars.TabIndex = 0;
            // 
            // lblopticalid
            // 
            this.lblopticalid.AutoSize = true;
            this.lblopticalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblopticalid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblopticalid.Location = new System.Drawing.Point(7, 6);
            this.lblopticalid.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblopticalid.Name = "lblopticalid";
            this.lblopticalid.Size = new System.Drawing.Size(14, 13);
            this.lblopticalid.TabIndex = 810;
            this.lblopticalid.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(209, 11);
            this.label24.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 16);
            this.label24.TabIndex = 768;
            this.label24.Text = "Optical Sell";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(6, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 16);
            this.label1.TabIndex = 766;
            this.label1.Text = "Qty";
            // 
            // lblno
            // 
            this.lblno.AutoSize = true;
            this.lblno.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblno.Location = new System.Drawing.Point(25, 28);
            this.lblno.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblno.Name = "lblno";
            this.lblno.Size = new System.Drawing.Size(0, 13);
            this.lblno.TabIndex = 764;
            // 
            // txtRate
            // 
            this.txtRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRate.Location = new System.Drawing.Point(223, 89);
            this.txtRate.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtRate.MaxLength = 15;
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(110, 22);
            this.txtRate.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(175, 91);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 16);
            this.label5.TabIndex = 754;
            this.label5.Text = "Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(6, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 754;
            this.label3.Text = "Particulars";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(358, 93);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 754;
            this.label2.Text = "Amount";
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(436, 91);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtAmount.MaxLength = 15;
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(121, 22);
            this.txtAmount.TabIndex = 3;
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.Location = new System.Drawing.Point(93, 88);
            this.txtQty.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtQty.MaxLength = 15;
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(77, 22);
            this.txtQty.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(1025, 285);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(85, 27);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // lbllefteye
            // 
            this.lbllefteye.AutoSize = true;
            this.lbllefteye.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllefteye.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbllefteye.Location = new System.Drawing.Point(869, 6);
            this.lbllefteye.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lbllefteye.Name = "lbllefteye";
            this.lbllefteye.Size = new System.Drawing.Size(79, 16);
            this.lbllefteye.TabIndex = 769;
            this.lbllefteye.Text = "LEFT EYE";
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReset.FlatAppearance.BorderSize = 0;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.ForeColor = System.Drawing.Color.Black;
            this.btnReset.Location = new System.Drawing.Point(932, 285);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(85, 27);
            this.btnReset.TabIndex = 0;
            this.btnReset.Text = "New";
            this.btnReset.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.lblglassidleft);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.txtldva);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.txtlnaxis);
            this.panel4.Controls.Add(this.txtldaxis);
            this.panel4.Controls.Add(this.txtlncyl);
            this.panel4.Controls.Add(this.txtldcyl);
            this.panel4.Controls.Add(this.txtlnsph);
            this.panel4.Controls.Add(this.txtldsph);
            this.panel4.Location = new System.Drawing.Point(626, 35);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(584, 142);
            this.panel4.TabIndex = 2;
            // 
            // lblglassidleft
            // 
            this.lblglassidleft.AutoSize = true;
            this.lblglassidleft.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblglassidleft.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblglassidleft.Location = new System.Drawing.Point(7, 6);
            this.lblglassidleft.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblglassidleft.Name = "lblglassidleft";
            this.lblglassidleft.Size = new System.Drawing.Size(14, 13);
            this.lblglassidleft.TabIndex = 808;
            this.lblglassidleft.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Location = new System.Drawing.Point(19, 56);
            this.label20.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 13);
            this.label20.TabIndex = 773;
            this.label20.Text = "D";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(19, 95);
            this.label21.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 13);
            this.label21.TabIndex = 772;
            this.label21.Text = "N";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(74, 14);
            this.label17.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 13);
            this.label17.TabIndex = 771;
            this.label17.Text = "SPH";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(287, 14);
            this.label18.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 770;
            this.label18.Text = "AXIS";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19.Location = new System.Drawing.Point(181, 14);
            this.label19.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 769;
            this.label19.Text = "CYL";
            // 
            // txtldva
            // 
            this.txtldva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtldva.Location = new System.Drawing.Point(368, 52);
            this.txtldva.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtldva.MaxLength = 15;
            this.txtldva.Name = "txtldva";
            this.txtldva.Size = new System.Drawing.Size(72, 20);
            this.txtldva.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(383, 14);
            this.label16.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 13);
            this.label16.TabIndex = 765;
            this.label16.Text = "V/A";
            // 
            // txtlnaxis
            // 
            this.txtlnaxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlnaxis.Location = new System.Drawing.Point(266, 91);
            this.txtlnaxis.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtlnaxis.MaxLength = 15;
            this.txtlnaxis.Name = "txtlnaxis";
            this.txtlnaxis.Size = new System.Drawing.Size(72, 20);
            this.txtlnaxis.TabIndex = 5;
            // 
            // txtldaxis
            // 
            this.txtldaxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtldaxis.Location = new System.Drawing.Point(266, 52);
            this.txtldaxis.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtldaxis.MaxLength = 15;
            this.txtldaxis.Name = "txtldaxis";
            this.txtldaxis.Size = new System.Drawing.Size(72, 20);
            this.txtldaxis.TabIndex = 2;
            // 
            // txtlncyl
            // 
            this.txtlncyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlncyl.Location = new System.Drawing.Point(164, 91);
            this.txtlncyl.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtlncyl.MaxLength = 15;
            this.txtlncyl.Name = "txtlncyl";
            this.txtlncyl.Size = new System.Drawing.Size(72, 20);
            this.txtlncyl.TabIndex = 4;
            // 
            // txtldcyl
            // 
            this.txtldcyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtldcyl.Location = new System.Drawing.Point(164, 52);
            this.txtldcyl.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtldcyl.MaxLength = 15;
            this.txtldcyl.Name = "txtldcyl";
            this.txtldcyl.Size = new System.Drawing.Size(72, 20);
            this.txtldcyl.TabIndex = 1;
            // 
            // txtlnsph
            // 
            this.txtlnsph.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlnsph.Location = new System.Drawing.Point(65, 92);
            this.txtlnsph.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtlnsph.MaxLength = 15;
            this.txtlnsph.Name = "txtlnsph";
            this.txtlnsph.Size = new System.Drawing.Size(72, 20);
            this.txtlnsph.TabIndex = 3;
            // 
            // txtldsph
            // 
            this.txtldsph.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtldsph.Location = new System.Drawing.Point(65, 53);
            this.txtldsph.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtldsph.MaxLength = 15;
            this.txtldsph.Name = "txtldsph";
            this.txtldsph.Size = new System.Drawing.Size(72, 20);
            this.txtldsph.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Location = new System.Drawing.Point(841, 284);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 27);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(102, 66);
            this.label12.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 764;
            this.label12.Text = "SPH";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(315, 66);
            this.label11.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 763;
            this.label11.Text = "AXIS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(209, 66);
            this.label10.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 762;
            this.label10.Text = "CYL";
            // 
            // lblrighteye
            // 
            this.lblrighteye.AutoSize = true;
            this.lblrighteye.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrighteye.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblrighteye.Location = new System.Drawing.Point(238, 6);
            this.lblrighteye.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblrighteye.Name = "lblrighteye";
            this.lblrighteye.Size = new System.Drawing.Size(89, 16);
            this.lblrighteye.TabIndex = 760;
            this.lblrighteye.Text = "RIGHT EYE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(25, 92);
            this.label8.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 13);
            this.label8.TabIndex = 759;
            this.label8.Text = "D";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(25, 131);
            this.label7.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 13);
            this.label7.TabIndex = 758;
            this.label7.Text = "N";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lblglassidright);
            this.panel3.Controls.Add(this.txtrdva);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.txtrnaxis);
            this.panel3.Controls.Add(this.txtrdaxis);
            this.panel3.Controls.Add(this.txtrncyl);
            this.panel3.Controls.Add(this.txtrdcyl);
            this.panel3.Controls.Add(this.txtrnsph);
            this.panel3.Controls.Add(this.txtrdsph);
            this.panel3.Location = new System.Drawing.Point(19, 35);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(584, 142);
            this.panel3.TabIndex = 1;
            // 
            // lblglassidright
            // 
            this.lblglassidright.AutoSize = true;
            this.lblglassidright.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblglassidright.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblglassidright.Location = new System.Drawing.Point(4, 6);
            this.lblglassidright.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblglassidright.Name = "lblglassidright";
            this.lblglassidright.Size = new System.Drawing.Size(14, 13);
            this.lblglassidright.TabIndex = 809;
            this.lblglassidright.Text = "0";
            // 
            // txtrdva
            // 
            this.txtrdva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrdva.Location = new System.Drawing.Point(368, 52);
            this.txtrdva.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrdva.MaxLength = 15;
            this.txtrdva.Name = "txtrdva";
            this.txtrdva.Size = new System.Drawing.Size(72, 20);
            this.txtrdva.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(383, 23);
            this.label13.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 13);
            this.label13.TabIndex = 765;
            this.label13.Text = "V/A";
            // 
            // txtrnaxis
            // 
            this.txtrnaxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrnaxis.Location = new System.Drawing.Point(266, 91);
            this.txtrnaxis.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrnaxis.MaxLength = 15;
            this.txtrnaxis.Name = "txtrnaxis";
            this.txtrnaxis.Size = new System.Drawing.Size(72, 20);
            this.txtrnaxis.TabIndex = 5;
            // 
            // txtrdaxis
            // 
            this.txtrdaxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrdaxis.Location = new System.Drawing.Point(266, 52);
            this.txtrdaxis.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrdaxis.MaxLength = 15;
            this.txtrdaxis.Name = "txtrdaxis";
            this.txtrdaxis.Size = new System.Drawing.Size(72, 20);
            this.txtrdaxis.TabIndex = 2;
            // 
            // txtrncyl
            // 
            this.txtrncyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrncyl.Location = new System.Drawing.Point(164, 91);
            this.txtrncyl.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrncyl.MaxLength = 15;
            this.txtrncyl.Name = "txtrncyl";
            this.txtrncyl.Size = new System.Drawing.Size(72, 20);
            this.txtrncyl.TabIndex = 4;
            // 
            // txtrdcyl
            // 
            this.txtrdcyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrdcyl.Location = new System.Drawing.Point(164, 52);
            this.txtrdcyl.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrdcyl.MaxLength = 15;
            this.txtrdcyl.Name = "txtrdcyl";
            this.txtrdcyl.Size = new System.Drawing.Size(72, 20);
            this.txtrdcyl.TabIndex = 1;
            // 
            // txtrnsph
            // 
            this.txtrnsph.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrnsph.Location = new System.Drawing.Point(65, 92);
            this.txtrnsph.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrnsph.MaxLength = 15;
            this.txtrnsph.Name = "txtrnsph";
            this.txtrnsph.Size = new System.Drawing.Size(72, 20);
            this.txtrnsph.TabIndex = 3;
            // 
            // txtrdsph
            // 
            this.txtrdsph.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrdsph.Location = new System.Drawing.Point(65, 53);
            this.txtrdsph.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtrdsph.MaxLength = 15;
            this.txtrdsph.Name = "txtrdsph";
            this.txtrdsph.Size = new System.Drawing.Size(72, 20);
            this.txtrdsph.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(992, 78);
            this.label22.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 16);
            this.label22.TabIndex = 821;
            this.label22.Text = "Mo. No.";
            // 
            // lbltempid
            // 
            this.lbltempid.AutoSize = true;
            this.lbltempid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltempid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbltempid.Location = new System.Drawing.Point(8, 7);
            this.lbltempid.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lbltempid.Name = "lbltempid";
            this.lbltempid.Size = new System.Drawing.Size(14, 13);
            this.lbltempid.TabIndex = 822;
            this.lbltempid.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(555, 78);
            this.label9.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 16);
            this.label9.TabIndex = 820;
            this.label9.Text = "Address";
            // 
            // txtmo
            // 
            this.txtmo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmo.Location = new System.Drawing.Point(1051, 75);
            this.txtmo.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtmo.MaxLength = 15;
            this.txtmo.Name = "txtmo";
            this.txtmo.Size = new System.Drawing.Size(193, 22);
            this.txtmo.TabIndex = 814;
            // 
            // txtaddress
            // 
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(631, 75);
            this.txtaddress.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtaddress.MaxLength = 15;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(344, 22);
            this.txtaddress.TabIndex = 813;
            // 
            // txtcustomer
            // 
            this.txtcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.Location = new System.Drawing.Point(169, 73);
            this.txtcustomer.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtcustomer.MaxLength = 15;
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(371, 22);
            this.txtcustomer.TabIndex = 812;
            // 
            // dtpinvoice
            // 
            this.dtpinvoice.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpinvoice.Location = new System.Drawing.Point(598, 29);
            this.dtpinvoice.Margin = new System.Windows.Forms.Padding(4);
            this.dtpinvoice.Name = "dtpinvoice";
            this.dtpinvoice.Size = new System.Drawing.Size(197, 20);
            this.dtpinvoice.TabIndex = 811;
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCustomer.Location = new System.Drawing.Point(37, 75);
            this.lblCustomer.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(73, 16);
            this.lblCustomer.TabIndex = 819;
            this.lblCustomer.Text = "Customer";
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceNo.Location = new System.Drawing.Point(173, 29);
            this.txtInvoiceNo.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.txtInvoiceNo.MaxLength = 15;
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.Size = new System.Drawing.Size(127, 22);
            this.txtInvoiceNo.TabIndex = 816;
            // 
            // lblInvoiceNo
            // 
            this.lblInvoiceNo.AutoSize = true;
            this.lblInvoiceNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblInvoiceNo.Location = new System.Drawing.Point(31, 33);
            this.lblInvoiceNo.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblInvoiceNo.Name = "lblInvoiceNo";
            this.lblInvoiceNo.Size = new System.Drawing.Size(86, 16);
            this.lblInvoiceNo.TabIndex = 818;
            this.lblInvoiceNo.Text = "Invoice No.";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDate.Location = new System.Drawing.Point(540, 33);
            this.lblDate.Margin = new System.Windows.Forms.Padding(7, 6, 7, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 16);
            this.lblDate.TabIndex = 817;
            this.lblDate.Text = "Date";
            // 
            // OPTICALSALE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1327, 581);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.lbltempid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtmo);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtcustomer);
            this.Controls.Add(this.dtpinvoice);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.txtInvoiceNo);
            this.Controls.Add(this.lblInvoiceNo);
            this.Controls.Add(this.lblDate);
            this.Name = "OPTICALSALE";
            this.Text = "OPTICALSALE";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbal;
        private System.Windows.Forms.TextBox txtadv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtpurticulars;
        private System.Windows.Forms.Label lblopticalid;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblno;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lbllefteye;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblglassidleft;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtldva;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtlnaxis;
        private System.Windows.Forms.TextBox txtldaxis;
        private System.Windows.Forms.TextBox txtlncyl;
        private System.Windows.Forms.TextBox txtldcyl;
        private System.Windows.Forms.TextBox txtlnsph;
        private System.Windows.Forms.TextBox txtldsph;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblrighteye;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblglassidright;
        private System.Windows.Forms.TextBox txtrdva;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtrnaxis;
        private System.Windows.Forms.TextBox txtrdaxis;
        private System.Windows.Forms.TextBox txtrncyl;
        private System.Windows.Forms.TextBox txtrdcyl;
        private System.Windows.Forms.TextBox txtrnsph;
        private System.Windows.Forms.TextBox txtrdsph;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbltempid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtmo;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtcustomer;
        private System.Windows.Forms.DateTimePicker dtpinvoice;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.TextBox txtInvoiceNo;
        private System.Windows.Forms.Label lblInvoiceNo;
        private System.Windows.Forms.Label lblDate;
    }
}