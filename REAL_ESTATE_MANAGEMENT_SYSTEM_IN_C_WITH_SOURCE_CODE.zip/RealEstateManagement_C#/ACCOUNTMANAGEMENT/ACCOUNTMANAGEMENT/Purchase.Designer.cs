﻿namespace ACCOUNTMANAGEMENT
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Purchase));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtModelNo = new System.Windows.Forms.TextBox();
            this.Amount1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.txttotaltax = new System.Windows.Forms.TextBox();
            this.txtTotqty = new System.Windows.Forms.TextBox();
            this.NetAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txttotdiscount = new System.Windows.Forms.TextBox();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtlrno = new System.Windows.Forms.TextBox();
            this.txtNetAmount = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lblTaxid = new System.Windows.Forms.Label();
            this.lblunitid = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblSlNo = new System.Windows.Forms.Label();
            this.txtBasicAmount = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSerialNo = new System.Windows.Forms.TextBox();
            this.Tax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtpCreditDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.lblpath = new System.Windows.Forms.Label();
            this.txttransport = new System.Windows.Forms.TextBox();
            this.dgwSales = new System.Windows.Forms.DataGridView();
            this.Slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SerialNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModelNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.txttax = new System.Windows.Forms.TextBox();
            this.txttaxname = new System.Windows.Forms.TextBox();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.txtdiscper = new System.Windows.Forms.TextBox();
            this.txtmrp = new System.Windows.Forms.TextBox();
            this.txtunit = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbitemname = new System.Windows.Forms.ComboBox();
            this.txtitemno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.btnAd = new System.Windows.Forms.Button();
            this.cmbSupplier = new System.Windows.Forms.ComboBox();
            this.lblSupplierid = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtVoucherNo = new System.Windows.Forms.TextBox();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.lblchange = new System.Windows.Forms.Label();
            this.GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSales)).BeginInit();
            this.SuspendLayout();
            // 
            // txtModelNo
            // 
            this.txtModelNo.Location = new System.Drawing.Point(861, 90);
            this.txtModelNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtModelNo.Name = "txtModelNo";
            this.txtModelNo.Size = new System.Drawing.Size(275, 20);
            this.txtModelNo.TabIndex = 367;
            this.txtModelNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtModelNo_KeyDown);
            // 
            // Amount1
            // 
            this.Amount1.HeaderText = "Amount";
            this.Amount1.Name = "Amount1";
            this.Amount1.ReadOnly = true;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.btnDelete);
            this.GroupBox3.Controls.Add(this.btnUpdate);
            this.GroupBox3.Controls.Add(this.btnNew);
            this.GroupBox3.Controls.Add(this.btnSave);
            this.GroupBox3.Controls.Add(this.btnClose);
            this.GroupBox3.Location = new System.Drawing.Point(10, 515);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(441, 62);
            this.GroupBox3.TabIndex = 361;
            this.GroupBox3.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(263, 16);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(82, 37);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(179, 16);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(82, 37);
            this.btnUpdate.TabIndex = 2;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.Location = new System.Drawing.Point(8, 14);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(82, 37);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "&New";
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(94, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(82, 37);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(350, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(82, 37);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "&Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txttotaltax
            // 
            this.txttotaltax.Location = new System.Drawing.Point(1039, 520);
            this.txttotaltax.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttotaltax.Name = "txttotaltax";
            this.txttotaltax.ReadOnly = true;
            this.txttotaltax.Size = new System.Drawing.Size(131, 20);
            this.txttotaltax.TabIndex = 360;
            this.txttotaltax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotqty
            // 
            this.txtTotqty.Location = new System.Drawing.Point(788, 520);
            this.txtTotqty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotqty.Name = "txtTotqty";
            this.txtTotqty.ReadOnly = true;
            this.txtTotqty.Size = new System.Drawing.Size(131, 20);
            this.txtTotqty.TabIndex = 359;
            this.txtTotqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // NetAmount
            // 
            this.NetAmount.HeaderText = "NetAmount";
            this.NetAmount.Name = "NetAmount";
            this.NetAmount.ReadOnly = true;
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.Location = new System.Drawing.Point(1039, 552);
            this.txtGrandTotal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.ReadOnly = true;
            this.txtGrandTotal.Size = new System.Drawing.Size(131, 20);
            this.txtGrandTotal.TabIndex = 354;
            this.txtGrandTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(923, 524);
            this.label18.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(107, 17);
            this.label18.TabIndex = 352;
            this.label18.Text = "Total Tax Amount";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(672, 557);
            this.label15.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 17);
            this.label15.TabIndex = 351;
            this.label15.Text = "Total Discount";
            // 
            // txttotdiscount
            // 
            this.txttotdiscount.Location = new System.Drawing.Point(788, 554);
            this.txttotdiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttotdiscount.Name = "txttotdiscount";
            this.txttotdiscount.Size = new System.Drawing.Size(131, 20);
            this.txttotdiscount.TabIndex = 350;
            // 
            // Discount
            // 
            this.Discount.HeaderText = "Discount";
            this.Discount.Name = "Discount";
            this.Discount.ReadOnly = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(931, 558);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 17);
            this.label20.TabIndex = 355;
            this.label20.Text = "Grand Total";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(672, 524);
            this.label14.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 17);
            this.label14.TabIndex = 349;
            this.label14.Text = "Total Qty";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label26.Location = new System.Drawing.Point(195, 490);
            this.label26.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(109, 17);
            this.label26.TabIndex = 380;
            this.label26.Text = "TRANSPORT BY.";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(7, 487);
            this.label25.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 17);
            this.label25.TabIndex = 378;
            this.label25.Text = "L.R. NO.";
            // 
            // txtlrno
            // 
            this.txtlrno.Location = new System.Drawing.Point(64, 486);
            this.txtlrno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtlrno.Name = "txtlrno";
            this.txtlrno.Size = new System.Drawing.Size(131, 20);
            this.txtlrno.TabIndex = 377;
            // 
            // txtNetAmount
            // 
            this.txtNetAmount.Location = new System.Drawing.Point(746, 147);
            this.txtNetAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNetAmount.Name = "txtNetAmount";
            this.txtNetAmount.ReadOnly = true;
            this.txtNetAmount.Size = new System.Drawing.Size(89, 20);
            this.txtNetAmount.TabIndex = 376;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(749, 117);
            this.label24.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 17);
            this.label24.TabIndex = 375;
            this.label24.Text = "Net Amount";
            // 
            // lblTaxid
            // 
            this.lblTaxid.AutoSize = true;
            this.lblTaxid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblTaxid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTaxid.Location = new System.Drawing.Point(635, 115);
            this.lblTaxid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblTaxid.Name = "lblTaxid";
            this.lblTaxid.Size = new System.Drawing.Size(14, 17);
            this.lblTaxid.TabIndex = 374;
            this.lblTaxid.Text = "1";
            // 
            // lblunitid
            // 
            this.lblunitid.AutoSize = true;
            this.lblunitid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblunitid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblunitid.Location = new System.Drawing.Point(178, 119);
            this.lblunitid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblunitid.Name = "lblunitid";
            this.lblunitid.Size = new System.Drawing.Size(14, 17);
            this.lblunitid.TabIndex = 373;
            this.lblunitid.Text = "1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(35, 64);
            this.label23.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 17);
            this.label23.TabIndex = 372;
            this.label23.Text = "Sl. No.";
            // 
            // lblSlNo
            // 
            this.lblSlNo.AutoSize = true;
            this.lblSlNo.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblSlNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSlNo.Location = new System.Drawing.Point(49, 92);
            this.lblSlNo.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblSlNo.Name = "lblSlNo";
            this.lblSlNo.Size = new System.Drawing.Size(14, 17);
            this.lblSlNo.TabIndex = 371;
            this.lblSlNo.Text = "1";
            // 
            // txtBasicAmount
            // 
            this.txtBasicAmount.Location = new System.Drawing.Point(466, 147);
            this.txtBasicAmount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBasicAmount.Name = "txtBasicAmount";
            this.txtBasicAmount.ReadOnly = true;
            this.txtBasicAmount.Size = new System.Drawing.Size(89, 20);
            this.txtBasicAmount.TabIndex = 370;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(469, 118);
            this.label22.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 17);
            this.label22.TabIndex = 369;
            this.label22.Text = "Basic Amount";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(959, 64);
            this.label21.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 17);
            this.label21.TabIndex = 368;
            this.label21.Text = "Model No";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(691, 63);
            this.label16.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 17);
            this.label16.TabIndex = 366;
            this.label16.Text = "Serial No";
            // 
            // txtSerialNo
            // 
            this.txtSerialNo.Location = new System.Drawing.Point(593, 91);
            this.txtSerialNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSerialNo.Name = "txtSerialNo";
            this.txtSerialNo.Size = new System.Drawing.Size(258, 20);
            this.txtSerialNo.TabIndex = 365;
            this.txtSerialNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSerialNo_KeyDown);
            // 
            // Tax
            // 
            this.Tax.HeaderText = "Tax";
            this.Tax.Name = "Tax";
            this.Tax.ReadOnly = true;
            // 
            // dtpCreditDate
            // 
            this.dtpCreditDate.CustomFormat = "dd/MM/yyyy";
            this.dtpCreditDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCreditDate.Location = new System.Drawing.Point(457, 548);
            this.dtpCreditDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpCreditDate.Name = "dtpCreditDate";
            this.dtpCreditDate.Size = new System.Drawing.Size(115, 20);
            this.dtpCreditDate.TabIndex = 364;
            this.dtpCreditDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpCreditDate_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(478, 520);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 17);
            this.label1.TabIndex = 363;
            this.label1.Text = "Credit Date";
            // 
            // lblpath
            // 
            this.lblpath.AutoSize = true;
            this.lblpath.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblpath.Location = new System.Drawing.Point(1293, 3);
            this.lblpath.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblpath.Name = "lblpath";
            this.lblpath.Size = new System.Drawing.Size(0, 13);
            this.lblpath.TabIndex = 362;
            // 
            // txttransport
            // 
            this.txttransport.Location = new System.Drawing.Point(309, 487);
            this.txttransport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttransport.Name = "txttransport";
            this.txttransport.Size = new System.Drawing.Size(263, 20);
            this.txttransport.TabIndex = 379;
            // 
            // dgwSales
            // 
            this.dgwSales.AllowUserToAddRows = false;
            this.dgwSales.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FloralWhite;
            this.dgwSales.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgwSales.BackgroundColor = System.Drawing.Color.White;
            this.dgwSales.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwSales.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgwSales.ColumnHeadersHeight = 24;
            this.dgwSales.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Slno,
            this.GroupId,
            this.dataGridViewTextBoxColumn1,
            this.SerialNo,
            this.ModelNo,
            this.Qty,
            this.Rate,
            this.amount,
            this.Tax,
            this.NetAmount,
            this.Discount,
            this.Amount1});
            this.dgwSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgwSales.EnableHeadersVisualStyles = false;
            this.dgwSales.GridColor = System.Drawing.Color.White;
            this.dgwSales.Location = new System.Drawing.Point(12, 173);
            this.dgwSales.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgwSales.MultiSelect = false;
            this.dgwSales.Name = "dgwSales";
            this.dgwSales.ReadOnly = true;
            this.dgwSales.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwSales.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgwSales.RowHeadersWidth = 25;
            this.dgwSales.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.MediumTurquoise;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.White;
            this.dgwSales.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgwSales.RowTemplate.Height = 18;
            this.dgwSales.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwSales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgwSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwSales.Size = new System.Drawing.Size(1159, 303);
            this.dgwSales.TabIndex = 348;
            // 
            // Slno
            // 
            this.Slno.HeaderText = "Sl.No.";
            this.Slno.Name = "Slno";
            this.Slno.ReadOnly = true;
            this.Slno.Width = 40;
            // 
            // GroupId
            // 
            this.GroupId.HeaderText = "Id";
            this.GroupId.Name = "GroupId";
            this.GroupId.ReadOnly = true;
            this.GroupId.Width = 70;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Item Name";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // SerialNo
            // 
            this.SerialNo.HeaderText = "SerialNo";
            this.SerialNo.Name = "SerialNo";
            this.SerialNo.ReadOnly = true;
            // 
            // ModelNo
            // 
            this.ModelNo.HeaderText = "ModelNo";
            this.ModelNo.Name = "ModelNo";
            this.ModelNo.ReadOnly = true;
            // 
            // Qty
            // 
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            this.Qty.ReadOnly = true;
            this.Qty.Width = 50;
            // 
            // Rate
            // 
            this.Rate.HeaderText = "Rate";
            this.Rate.Name = "Rate";
            this.Rate.ReadOnly = true;
            // 
            // amount
            // 
            this.amount.HeaderText = "Basic Amount";
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            // 
            // txtamount
            // 
            this.txtamount.Location = new System.Drawing.Point(1017, 144);
            this.txtamount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtamount.Name = "txtamount";
            this.txtamount.ReadOnly = true;
            this.txtamount.Size = new System.Drawing.Size(119, 20);
            this.txtamount.TabIndex = 347;
            // 
            // txttax
            // 
            this.txttax.Location = new System.Drawing.Point(658, 147);
            this.txttax.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttax.Name = "txttax";
            this.txttax.ReadOnly = true;
            this.txttax.Size = new System.Drawing.Size(84, 20);
            this.txttax.TabIndex = 346;
            // 
            // txttaxname
            // 
            this.txttaxname.Location = new System.Drawing.Point(560, 147);
            this.txttaxname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txttaxname.Name = "txttaxname";
            this.txttaxname.ReadOnly = true;
            this.txttaxname.Size = new System.Drawing.Size(91, 20);
            this.txttaxname.TabIndex = 345;
            // 
            // txtdiscount
            // 
            this.txtdiscount.Location = new System.Drawing.Point(928, 145);
            this.txtdiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(77, 20);
            this.txtdiscount.TabIndex = 344;
            this.txtdiscount.Text = "0";
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged);
            this.txtdiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtdiscount_KeyDown);
            // 
            // txtdiscper
            // 
            this.txtdiscper.Location = new System.Drawing.Point(842, 146);
            this.txtdiscper.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtdiscper.Name = "txtdiscper";
            this.txtdiscper.Size = new System.Drawing.Size(77, 20);
            this.txtdiscper.TabIndex = 343;
            this.txtdiscper.Text = "0";
            this.txtdiscper.TextChanged += new System.EventHandler(this.txtdiscper_TextChanged);
            this.txtdiscper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtdiscper_KeyDown);
            // 
            // txtmrp
            // 
            this.txtmrp.Location = new System.Drawing.Point(342, 147);
            this.txtmrp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtmrp.Name = "txtmrp";
            this.txtmrp.ReadOnly = true;
            this.txtmrp.Size = new System.Drawing.Size(114, 20);
            this.txtmrp.TabIndex = 342;
            // 
            // txtunit
            // 
            this.txtunit.Location = new System.Drawing.Point(128, 147);
            this.txtunit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtunit.Name = "txtunit";
            this.txtunit.ReadOnly = true;
            this.txtunit.Size = new System.Drawing.Size(77, 20);
            this.txtunit.TabIndex = 341;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(1041, 113);
            this.label13.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 17);
            this.label13.TabIndex = 340;
            this.label13.Text = "Amount";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(148, 117);
            this.label12.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 17);
            this.label12.TabIndex = 339;
            this.label12.Text = "unit";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(665, 115);
            this.label11.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 17);
            this.label11.TabIndex = 338;
            this.label11.Text = "Tax Amount";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(573, 115);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 17);
            this.label10.TabIndex = 337;
            this.label10.Text = "Tax Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(935, 113);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 17);
            this.label9.TabIndex = 336;
            this.label9.Text = "Discount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(379, 119);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 17);
            this.label8.TabIndex = 335;
            this.label8.Text = "Mrp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(846, 115);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 334;
            this.label7.Text = "Discount%";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(108, 63);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 332;
            this.label6.Text = "Item No";
            // 
            // cmbitemname
            // 
            this.cmbitemname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbitemname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbitemname.FormattingEnabled = true;
            this.cmbitemname.Location = new System.Drawing.Point(204, 90);
            this.cmbitemname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbitemname.Name = "cmbitemname";
            this.cmbitemname.Size = new System.Drawing.Size(370, 21);
            this.cmbitemname.TabIndex = 333;
            this.cmbitemname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbitemname_KeyDown);
            // 
            // txtitemno
            // 
            this.txtitemno.Location = new System.Drawing.Point(87, 90);
            this.txtitemno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtitemno.Name = "txtitemno";
            this.txtitemno.Size = new System.Drawing.Size(100, 20);
            this.txtitemno.TabIndex = 331;
            this.txtitemno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtitemno_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(256, 119);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 17);
            this.label5.TabIndex = 330;
            this.label5.Text = "Price";
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(219, 147);
            this.txtprice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(114, 20);
            this.txtprice.TabIndex = 329;
            this.txtprice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtprice_KeyDown);
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(51, 147);
            this.txtqty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(67, 20);
            this.txtqty.TabIndex = 327;
            this.txtqty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtqty_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(72, 119);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 17);
            this.label4.TabIndex = 328;
            this.label4.Text = "Qty";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(328, 64);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 17);
            this.label3.TabIndex = 326;
            this.label3.Text = "Item Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(318, 28);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 325;
            this.label2.Text = "Invoice No";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Location = new System.Drawing.Point(384, 26);
            this.txtinvoiceno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(99, 20);
            this.txtinvoiceno.TabIndex = 324;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(15, 24);
            this.label17.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 17);
            this.label17.TabIndex = 323;
            this.label17.Text = "Date";
            // 
            // dtpDate
            // 
            this.dtpDate.CustomFormat = "dd/MM/yyyy";
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(61, 24);
            this.dtpDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(82, 20);
            this.dtpDate.TabIndex = 322;
            // 
            // btnAd
            // 
            this.btnAd.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAd.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAd.ForeColor = System.Drawing.Color.Green;
            this.btnAd.Location = new System.Drawing.Point(1142, 19);
            this.btnAd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAd.Name = "btnAd";
            this.btnAd.Size = new System.Drawing.Size(31, 35);
            this.btnAd.TabIndex = 319;
            this.btnAd.Text = "+";
            this.btnAd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAd.UseVisualStyleBackColor = true;
            this.btnAd.Click += new System.EventHandler(this.btnAd_Click);
            // 
            // cmbSupplier
            // 
            this.cmbSupplier.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSupplier.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSupplier.FormattingEnabled = true;
            this.cmbSupplier.Location = new System.Drawing.Point(786, 27);
            this.cmbSupplier.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSupplier.Name = "cmbSupplier";
            this.cmbSupplier.Size = new System.Drawing.Size(350, 21);
            this.cmbSupplier.TabIndex = 318;
            this.cmbSupplier.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbSupplier_KeyDown);
            // 
            // lblSupplierid
            // 
            this.lblSupplierid.AutoSize = true;
            this.lblSupplierid.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblSupplierid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSupplierid.Location = new System.Drawing.Point(678, 27);
            this.lblSupplierid.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblSupplierid.Name = "lblSupplierid";
            this.lblSupplierid.Size = new System.Drawing.Size(14, 17);
            this.lblSupplierid.TabIndex = 321;
            this.lblSupplierid.Text = "0";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblCompanyName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCompanyName.Location = new System.Drawing.Point(697, 27);
            this.lblCompanyName.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(89, 17);
            this.lblCompanyName.TabIndex = 320;
            this.lblCompanyName.Text = "Supplier Name";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label27.Location = new System.Drawing.Point(144, 27);
            this.label27.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 17);
            this.label27.TabIndex = 382;
            this.label27.Text = "Voucher No";
            // 
            // txtVoucherNo
            // 
            this.txtVoucherNo.Location = new System.Drawing.Point(219, 25);
            this.txtVoucherNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.Size = new System.Drawing.Size(90, 20);
            this.txtVoucherNo.TabIndex = 381;
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "dd/MM/yyyy";
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(558, 27);
            this.dtpInvoiceDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(115, 20);
            this.dtpInvoiceDate.TabIndex = 384;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19.Location = new System.Drawing.Point(485, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 17);
            this.label19.TabIndex = 383;
            this.label19.Text = "InvoiceDate";
            // 
            // lblchange
            // 
            this.lblchange.AutoSize = true;
            this.lblchange.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.lblchange.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblchange.Location = new System.Drawing.Point(1159, 90);
            this.lblchange.Margin = new System.Windows.Forms.Padding(6, 7, 6, 0);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(14, 17);
            this.lblchange.TabIndex = 385;
            this.lblchange.Text = "1";
            this.lblchange.TextChanged += new System.EventHandler(this.lblchange_TextChanged);
            // 
            // Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1223, 591);
            this.Controls.Add(this.lblchange);
            this.Controls.Add(this.txtinvoiceno);
            this.Controls.Add(this.dtpInvoiceDate);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.txtVoucherNo);
            this.Controls.Add(this.txtModelNo);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.txttotaltax);
            this.Controls.Add(this.txtTotqty);
            this.Controls.Add(this.txtGrandTotal);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txttotdiscount);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtlrno);
            this.Controls.Add(this.txtNetAmount);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.lblTaxid);
            this.Controls.Add(this.lblunitid);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.lblSlNo);
            this.Controls.Add(this.txtBasicAmount);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtSerialNo);
            this.Controls.Add(this.dtpCreditDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblpath);
            this.Controls.Add(this.txttransport);
            this.Controls.Add(this.dgwSales);
            this.Controls.Add(this.txtamount);
            this.Controls.Add(this.txttax);
            this.Controls.Add(this.txttaxname);
            this.Controls.Add(this.txtdiscount);
            this.Controls.Add(this.txtdiscper);
            this.Controls.Add(this.txtmrp);
            this.Controls.Add(this.txtunit);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmbitemname);
            this.Controls.Add(this.txtitemno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.btnAd);
            this.Controls.Add(this.cmbSupplier);
            this.Controls.Add(this.lblSupplierid);
            this.Controls.Add(this.lblCompanyName);
            this.Name = "Purchase";
            this.Text = "Purchase";
            this.GroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwSales)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtModelNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount1;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Button btnNew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button btnClose;
        internal System.Windows.Forms.TextBox txttotaltax;
        internal System.Windows.Forms.TextBox txtTotqty;
        private System.Windows.Forms.DataGridViewTextBoxColumn NetAmount;
        internal System.Windows.Forms.TextBox txtGrandTotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txttotdiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtlrno;
        private System.Windows.Forms.TextBox txtNetAmount;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblTaxid;
        private System.Windows.Forms.Label lblunitid;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblSlNo;
        private System.Windows.Forms.TextBox txtBasicAmount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSerialNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tax;
        internal System.Windows.Forms.DateTimePicker dtpCreditDate;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblpath;
        private System.Windows.Forms.TextBox txttransport;
        internal System.Windows.Forms.DataGridView dgwSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn Slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SerialNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModelNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.TextBox txtamount;
        private System.Windows.Forms.TextBox txttax;
        private System.Windows.Forms.TextBox txttaxname;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.TextBox txtdiscper;
        private System.Windows.Forms.TextBox txtmrp;
        private System.Windows.Forms.TextBox txtunit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtitemno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label label17;
        internal System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Button btnAd;
        private System.Windows.Forms.Label lblSupplierid;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtVoucherNo;
        internal System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.Label label19;
        public System.Windows.Forms.ComboBox cmbSupplier;
        public System.Windows.Forms.ComboBox cmbitemname;
        public System.Windows.Forms.Label lblchange;
    }
}