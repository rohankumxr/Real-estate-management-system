﻿namespace ACCOUNTMANAGEMENT {
    
    
    public partial class AccountDataSet {
    }
}
namespace ACCOUNTMANAGEMENT {
    
    
    public partial class AccountDataSet {
    }
}
