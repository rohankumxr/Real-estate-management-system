﻿namespace ACCOUNTMANAGEMENT
{
    partial class PLOTSELL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PLOTSELL));
            this.lblcustid = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblplotsell = new System.Windows.Forms.Label();
            this.txtplotno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtsurveyno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtplotsize = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtrate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txttotalamount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbookingamout = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtagreementamount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txttotalpaidamount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtbalanceamount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.txtinstallment = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dgvinstallment = new System.Windows.Forms.DataGridView();
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.INSTALLMENT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtinstallmentno = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtremainingamount = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txttotalinstallmentamount = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblpath = new System.Windows.Forms.Label();
            this.txtextradetail = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.btnAd = new System.Windows.Forms.Button();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvinstallment)).BeginInit();
            this.GroupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblcustid
            // 
            this.lblcustid.AutoSize = true;
            this.lblcustid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcustid.Location = new System.Drawing.Point(13, 56);
            this.lblcustid.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblcustid.Name = "lblcustid";
            this.lblcustid.Size = new System.Drawing.Size(13, 13);
            this.lblcustid.TabIndex = 206;
            this.lblcustid.Text = "0";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCompanyName.Location = new System.Drawing.Point(30, 55);
            this.lblCompanyName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(82, 13);
            this.lblCompanyName.TabIndex = 205;
            this.lblCompanyName.Text = "Customer Name";
            // 
            // lblplotsell
            // 
            this.lblplotsell.AutoSize = true;
            this.lblplotsell.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblplotsell.Location = new System.Drawing.Point(14, 37);
            this.lblplotsell.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblplotsell.Name = "lblplotsell";
            this.lblplotsell.Size = new System.Drawing.Size(13, 13);
            this.lblplotsell.TabIndex = 207;
            this.lblplotsell.Text = "0";
            // 
            // txtplotno
            // 
            this.txtplotno.Location = new System.Drawing.Point(614, 53);
            this.txtplotno.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtplotno.Name = "txtplotno";
            this.txtplotno.Size = new System.Drawing.Size(151, 20);
            this.txtplotno.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(510, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 209;
            this.label1.Text = "Plot No";
            // 
            // txtsurveyno
            // 
            this.txtsurveyno.Location = new System.Drawing.Point(134, 87);
            this.txtsurveyno.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtsurveyno.Name = "txtsurveyno";
            this.txtsurveyno.Size = new System.Drawing.Size(151, 20);
            this.txtsurveyno.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(30, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 211;
            this.label2.Text = "Survey No";
            // 
            // txtplotsize
            // 
            this.txtplotsize.Location = new System.Drawing.Point(614, 89);
            this.txtplotsize.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtplotsize.Name = "txtplotsize";
            this.txtplotsize.Size = new System.Drawing.Size(151, 20);
            this.txtplotsize.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(510, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 213;
            this.label3.Text = "Plot Size";
            // 
            // txtrate
            // 
            this.txtrate.Location = new System.Drawing.Point(134, 122);
            this.txtrate.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtrate.Name = "txtrate";
            this.txtrate.Size = new System.Drawing.Size(151, 20);
            this.txtrate.TabIndex = 5;
            this.txtrate.TextChanged += new System.EventHandler(this.txtrate_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(30, 124);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 215;
            this.label4.Text = "Rate";
            // 
            // txttotalamount
            // 
            this.txttotalamount.Location = new System.Drawing.Point(614, 124);
            this.txttotalamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txttotalamount.Name = "txttotalamount";
            this.txttotalamount.ReadOnly = true;
            this.txttotalamount.Size = new System.Drawing.Size(151, 20);
            this.txttotalamount.TabIndex = 5;
            this.txttotalamount.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(510, 126);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 217;
            this.label5.Text = "Total Amount";
            // 
            // txtbookingamout
            // 
            this.txtbookingamout.Location = new System.Drawing.Point(134, 156);
            this.txtbookingamout.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtbookingamout.Name = "txtbookingamout";
            this.txtbookingamout.Size = new System.Drawing.Size(151, 20);
            this.txtbookingamout.TabIndex = 6;
            this.txtbookingamout.TextChanged += new System.EventHandler(this.txtbookingamout_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(30, 158);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 219;
            this.label6.Text = "Booking Amount";
            // 
            // txtagreementamount
            // 
            this.txtagreementamount.Location = new System.Drawing.Point(614, 158);
            this.txtagreementamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtagreementamount.Name = "txtagreementamount";
            this.txtagreementamount.Size = new System.Drawing.Size(151, 20);
            this.txtagreementamount.TabIndex = 7;
            this.txtagreementamount.TextChanged += new System.EventHandler(this.txtagreementamount_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(510, 160);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 221;
            this.label7.Text = "Agreement Amount";
            // 
            // txttotalpaidamount
            // 
            this.txttotalpaidamount.Location = new System.Drawing.Point(134, 191);
            this.txttotalpaidamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txttotalpaidamount.Name = "txttotalpaidamount";
            this.txttotalpaidamount.ReadOnly = true;
            this.txttotalpaidamount.Size = new System.Drawing.Size(151, 20);
            this.txttotalpaidamount.TabIndex = 8;
            this.txttotalpaidamount.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(30, 193);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 13);
            this.label8.TabIndex = 223;
            this.label8.Text = "Total Paid Amount ";
            // 
            // txtbalanceamount
            // 
            this.txtbalanceamount.Location = new System.Drawing.Point(614, 193);
            this.txtbalanceamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtbalanceamount.Name = "txtbalanceamount";
            this.txtbalanceamount.ReadOnly = true;
            this.txtbalanceamount.Size = new System.Drawing.Size(151, 20);
            this.txtbalanceamount.TabIndex = 9;
            this.txtbalanceamount.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(510, 195);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 13);
            this.label9.TabIndex = 225;
            this.label9.Text = "Balance Amount ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(270, 19);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 227;
            this.label10.Text = "Installment";
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "dd/MMM/yyyy";
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(101, 284);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(120, 20);
            this.dtpInvoiceDate.TabIndex = 9;
            this.dtpInvoiceDate.Leave += new System.EventHandler(this.dtpInvoiceDate_Leave);
            // 
            // txtinstallment
            // 
            this.txtinstallment.Location = new System.Drawing.Point(226, 39);
            this.txtinstallment.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtinstallment.Name = "txtinstallment";
            this.txtinstallment.Size = new System.Drawing.Size(142, 20);
            this.txtinstallment.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(143, 21);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Date";
            // 
            // dgvinstallment
            // 
            this.dgvinstallment.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvinstallment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvinstallment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.Date,
            this.INSTALLMENT});
            this.dgvinstallment.Location = new System.Drawing.Point(9, 90);
            this.dgvinstallment.Name = "dgvinstallment";
            this.dgvinstallment.Size = new System.Drawing.Size(406, 194);
            this.dgvinstallment.TabIndex = 231;
            // 
            // No
            // 
            this.No.HeaderText = "No";
            this.No.Name = "No";
            this.No.Width = 50;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.Width = 50;
            // 
            // INSTALLMENT
            // 
            this.INSTALLMENT.HeaderText = "INSTALLMENT AMOUNT";
            this.INSTALLMENT.Name = "INSTALLMENT";
            this.INSTALLMENT.Width = 150;
            // 
            // txtinstallmentno
            // 
            this.txtinstallmentno.Location = new System.Drawing.Point(26, 37);
            this.txtinstallmentno.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtinstallmentno.Name = "txtinstallmentno";
            this.txtinstallmentno.Size = new System.Drawing.Size(46, 20);
            this.txtinstallmentno.TabIndex = 233;
            this.txtinstallmentno.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(36, 19);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 13);
            this.label12.TabIndex = 232;
            this.label12.Text = "No";
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Green;
            this.btnDelete.Location = new System.Drawing.Point(448, 39);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(66, 25);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Green;
            this.btnAdd.Location = new System.Drawing.Point(376, 39);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(66, 25);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.btn_new);
            this.GroupBox2.Controls.Add(this.btn_delete);
            this.GroupBox2.Controls.Add(this.btn_save);
            this.GroupBox2.Controls.Add(this.btn_close);
            this.GroupBox2.Controls.Add(this.btn_update);
            this.GroupBox2.Location = new System.Drawing.Point(675, 284);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(101, 222);
            this.GroupBox2.TabIndex = 237;
            this.GroupBox2.TabStop = false;
            // 
            // btn_new
            // 
            this.btn_new.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Image = ((System.Drawing.Image)(resources.GetObject("btn_new.Image")));
            this.btn_new.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_new.Location = new System.Drawing.Point(8, 12);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(83, 36);
            this.btn_new.TabIndex = 0;
            this.btn_new.Text = "&New";
            this.btn_new.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_delete.Location = new System.Drawing.Point(8, 138);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(83, 36);
            this.btn_delete.TabIndex = 3;
            this.btn_delete.Text = "&Delete";
            this.btn_delete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_delete.UseVisualStyleBackColor = true;
            // 
            // btn_save
            // 
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_save.Location = new System.Drawing.Point(8, 54);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(83, 36);
            this.btn_save.TabIndex = 1;
            this.btn_save.Text = "&Save";
            this.btn_save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_close
            // 
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_close.Location = new System.Drawing.Point(8, 180);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(83, 36);
            this.btn_close.TabIndex = 4;
            this.btn_close.Text = "&Close";
            this.btn_close.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_update
            // 
            this.btn_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_update.Location = new System.Drawing.Point(8, 96);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(83, 36);
            this.btn_update.TabIndex = 2;
            this.btn_update.Text = "&Update";
            this.btn_update.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bell MT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(15, 316);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(212, 13);
            this.label13.TabIndex = 238;
            this.label13.Text = "Note: For Deletion, 1st select a Desire Row.)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtremainingamount);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txttotalinstallmentamount);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.dgvinstallment);
            this.groupBox1.Controls.Add(this.txtinstallmentno);
            this.groupBox1.Controls.Add(this.txtinstallment);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Location = new System.Drawing.Point(3, 245);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(595, 291);
            this.groupBox1.TabIndex = 239;
            this.groupBox1.TabStop = false;
            // 
            // txtremainingamount
            // 
            this.txtremainingamount.Location = new System.Drawing.Point(423, 179);
            this.txtremainingamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtremainingamount.Name = "txtremainingamount";
            this.txtremainingamount.Size = new System.Drawing.Size(142, 20);
            this.txtremainingamount.TabIndex = 241;
            this.txtremainingamount.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(420, 157);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 13);
            this.label16.TabIndex = 240;
            this.label16.Text = "Remaining Installment Amount";
            // 
            // txttotalinstallmentamount
            // 
            this.txttotalinstallmentamount.Location = new System.Drawing.Point(423, 124);
            this.txttotalinstallmentamount.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txttotalinstallmentamount.Name = "txttotalinstallmentamount";
            this.txttotalinstallmentamount.Size = new System.Drawing.Size(142, 20);
            this.txttotalinstallmentamount.TabIndex = 239;
            this.txttotalinstallmentamount.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(430, 104);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 13);
            this.label15.TabIndex = 238;
            this.label15.Text = "Total Installment Amount";
            // 
            // lblpath
            // 
            this.lblpath.AutoSize = true;
            this.lblpath.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblpath.Location = new System.Drawing.Point(824, 10);
            this.lblpath.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.lblpath.Name = "lblpath";
            this.lblpath.Size = new System.Drawing.Size(0, 13);
            this.lblpath.TabIndex = 240;
            // 
            // txtextradetail
            // 
            this.txtextradetail.Location = new System.Drawing.Point(134, 222);
            this.txtextradetail.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.txtextradetail.Name = "txtextradetail";
            this.txtextradetail.Size = new System.Drawing.Size(355, 20);
            this.txtextradetail.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(30, 225);
            this.label14.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 13);
            this.label14.TabIndex = 242;
            this.label14.Text = "Extra Detail";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.Location = new System.Drawing.Point(134, 52);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(311, 21);
            this.cmbCustomer.TabIndex = 0;
            this.cmbCustomer.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cmbCustomer_KeyUp);
            this.cmbCustomer.Leave += new System.EventHandler(this.cmbCustomer_Leave);
            // 
            // btnAd
            // 
            this.btnAd.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAd.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAd.ForeColor = System.Drawing.Color.Green;
            this.btnAd.Location = new System.Drawing.Point(451, 51);
            this.btnAd.Name = "btnAd";
            this.btnAd.Size = new System.Drawing.Size(27, 27);
            this.btnAd.TabIndex = 1;
            this.btnAd.Text = "+";
            this.btnAd.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAd.UseVisualStyleBackColor = true;
            this.btnAd.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtpDate
            // 
            this.dtpDate.CustomFormat = "dd/MM/yyyy";
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(134, 21);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(99, 20);
            this.dtpDate.TabIndex = 243;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(30, 23);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 5, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 244;
            this.label17.Text = "Date";
            // 
            // PLOTSELL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(846, 536);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.btnAd);
            this.Controls.Add(this.cmbCustomer);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtextradetail);
            this.Controls.Add(this.lblpath);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dtpInvoiceDate);
            this.Controls.Add(this.txtbalanceamount);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txttotalpaidamount);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtagreementamount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbookingamout);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txttotalamount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtrate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtplotsize);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtsurveyno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtplotno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblplotsell);
            this.Controls.Add(this.lblcustid);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.groupBox1);
            this.Name = "PLOTSELL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PLOTSELL";
            this.Load += new System.EventHandler(this.PLOTSELL_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvinstallment)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcustid;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label lblplotsell;
        private System.Windows.Forms.TextBox txtplotno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsurveyno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtplotsize;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtrate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttotalamount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbookingamout;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtagreementamount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txttotalpaidamount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtbalanceamount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.TextBox txtinstallment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgvinstallment;
        private System.Windows.Forms.TextBox txtinstallmentno;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button btn_new;
        internal System.Windows.Forms.Button btn_delete;
        internal System.Windows.Forms.Button btn_save;
        internal System.Windows.Forms.Button btn_close;
        internal System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Label lblpath;
        private System.Windows.Forms.TextBox txtextradetail;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txttotalinstallmentamount;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn INSTALLMENT;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.Button btnAd;
        private System.Windows.Forms.TextBox txtremainingamount;
        private System.Windows.Forms.Label label16;
        internal System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label label17;
    }
}